# Aspect-Based-Sentiment-Analysis-on-Financial-News-and-Posts

Submitted to ELSEVIER-Knowledge Based Systems

publication descriptionSubmitted to ELSEVIER-Knowledge Based Systems. Developed efficient Deep Learning models in Python for this challenge and proposed a novel based model in which handcrafted features gives clues to pay more attention to the sentiment while maintaining the high-performance accuracy comparable to the state-of-the-art models in the problem. To the best of our knowledge, the proposed model, outperforms the existing models, making this model an optimal choice for this domain.
